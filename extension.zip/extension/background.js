const API = 'https://ansuz-back.vercel.app/api'

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message)
    .then(sendResponse)
    .catch(err => sendResponse({ error: err.message }))
  return true // Garde le canal ouvert pour la réponse async
})

async function handleMessage(msg) {
  if (msg.action === 'login') {
    const res = await fetch(`${API}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: msg.email, password: msg.password }),
    })
    const data = await res.json()
    if (!res.ok) return { error: data.error }
    return data
  }

  if (msg.action === 'createPost') {
    const { action, token, ...payload } = msg
    const res = await fetch(`${API}/posts`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify(payload),
    })
    const data = await res.json()
    if (!res.ok) return { error: data.error, status: res.status }
    return data
  }

  if (msg.action === 'searchCovers') {
    const res = await fetch(`${API}/search/covers?q=${encodeURIComponent(msg.q)}`)
    const data = await res.json()
    if (!res.ok) return { error: data.error }
    return { results: data }
  }

  return { error: 'Action inconnue' }
}
